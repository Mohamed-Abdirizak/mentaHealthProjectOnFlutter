import 'package:flutter/material.dart';

class feelings_face extends StatelessWidget {
  final String emojiText;
  const feelings_face({
    super.key,
    required this.emojiText,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: Colors.blue[400], borderRadius: BorderRadius.circular(12)),
      child: Text(
        this.emojiText,
        style: TextStyle(fontSize: 30),
      ),
    );
  }
}
