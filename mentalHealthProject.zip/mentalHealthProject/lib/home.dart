import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:ishooskeenid/listviews.dart';
import 'package:ishooskeenid/utilties/feeling_face.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DEVELOPD BY ENG FATIH"),
        centerTitle: true,
      ),
      backgroundColor: Colors.blue[800],
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(
            icon: Icon(Icons.notifications), label: "notifications"),
        BottomNavigationBarItem(icon: Icon(Icons.favorite), label: "favorite"),
      ]),
      body: SafeArea(
        child: Column(
          children: [
            //// inside one row....
            Padding(
              padding: const EdgeInsets.all(60.0),

              /// greeting or the first row contains hi faith, notificaiton icons with bg, date.
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  /////// this column wuxuu iga caawinaa in hi,fatih hoostiisa aan kuqoro texti yar....
                  ///wihotu going new line after the icon..
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Hi, Fatih!",
                        style: TextStyle(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "16 August 2023",
                        style: TextStyle(color: Colors.blue[200], fontSize: 20),
                      )
                    ],
                  ),
                  ///// the column ends here...
                  Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.blue[400],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.notifications,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  // Text("hello")
                ],
              ),
            ),
////// serch textfied(fake ah)..................
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                      color: Colors.blue[400],
                      borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    children: [
                      Icon(
                        Icons.search,
                        size: 40,
                        color: Colors.white,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "Search",
                        style: TextStyle(color: Colors.white, fontSize: 20),
                      )
                    ],
                  )),
            ),
////// serch textfied(fake ah) ends here.....................

//// one row: contains : text (how do you feel?) and icon(more).
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "How do you feel?",
                    style: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Icon(
                    Icons.more_horiz,
                    size: 40,
                    color: Colors.white,
                  )
                ],
              ),
            ),

//// one row: contains : text (how do you feel?) and icon(more) ends rherer..................

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                //// bad icon..
                Column(
                  children: [
                    feelings_face(emojiText: "😔"),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Bad",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    )
                  ],
                ),

                // fine...
                Column(
                  children: [
                    feelings_face(emojiText: "😃"),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Fine",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    )
                  ],
                ),

                //well
                Column(
                  children: [
                    feelings_face(emojiText: "🙃"),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Well",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    )
                  ],
                ),

                /// excellent..
                Column(
                  children: [
                    feelings_face(emojiText: "🤗"),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "Excellent",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    )
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),

            Expanded(
                child: Container(
              color: Colors.grey[200],
              child: Center(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20.0),

                      /// exercises and icon(more) line...
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Exercises",
                            style: TextStyle(
                                fontSize: 25, fontWeight: FontWeight.bold),
                          ),
                          Icon(
                            Icons.more_horiz,
                            size: 50,
                          )
                        ],
                      ),
                    ),

                    Expanded(
                      child: ListView(
                        children: [
                          listViews(
                              skillName: "Speaking Skill",
                              howManyExercises: "17 Exercises",
                              icon: Icons.mic,
                              color: Colors.blue),
                          listViews(
                              skillName: "Reading Skill",
                              howManyExercises: "29 Exercises",
                              icon: Icons.book,
                              color: Colors.red),
                          listViews(
                              skillName: "Football Skill",
                              howManyExercises: "17 Exercises",
                              icon: Icons.sports_football,
                              color: Colors.orange),
                          listViews(
                              skillName: "Computer Skill",
                              howManyExercises: "50 Exercises",
                              icon: Icons.computer,
                              color: Colors.blue),
                          listViews(
                              skillName: "Language Skill",
                              howManyExercises: "120 Exercises",
                              icon: Icons.type_specimen,
                              color: Colors.green)
                        ],
                      ),
                    )

                    /// exercises and icon(more) line... ends here.....
                    // Padding(
                    //   padding: const EdgeInsets.all(20.0),
                    //   child: Container(
                    //     decoration: BoxDecoration(
                    //         color: Colors.white,
                    //         borderRadius: BorderRadius.circular(12)),
                    //     child: Column(
                    //       children: [
                    //         Padding(
                    //           padding: const EdgeInsets.all(15.0),
                    //           child: Row(
                    //             mainAxisAlignment:
                    //                 MainAxisAlignment.spaceBetween,
                    //             children: [
                    //               Row(
                    //                 children: [
                    //                   Container(
                    //                     padding: EdgeInsets.all(15),
                    //                     decoration: BoxDecoration(
                    //                         color: Colors.orange,
                    //                         borderRadius:
                    //                             BorderRadius.circular(12)),
                    //                     child: Icon(
                    //                       Icons.favorite,
                    //                       size: 50,
                    //                     ),
                    //                   ),
                    //                   SizedBox(
                    //                     width: 10,
                    //                   ),
                    //                   Column(
                    //                     crossAxisAlignment:
                    //                         CrossAxisAlignment.start,
                    //                     children: [
                    //                       Text(
                    //                         "Speaking Skills",
                    //                         style: TextStyle(
                    //                             fontSize: 20,
                    //                             fontWeight: FontWeight.bold),
                    //                       ),
                    //                       Text(
                    //                         "16 exercises",
                    //                         style: TextStyle(fontSize: 16),
                    //                       ),
                    //                     ],
                    //                   ),
                    //                 ],
                    //               ),
                    //               Icon(
                    //                 Icons.more_horiz,
                    //                 size: 50,
                    //               ),
                    //             ],
                    //           ),
                    //         )
                    //       ],
                    //     ),
                    //   ),
                    // )
                  ],
                ),
              ),
            ))

////////////////////////
          ],
        ),
      ),
    );
  }
}
