package com.example.ishooskeenid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
